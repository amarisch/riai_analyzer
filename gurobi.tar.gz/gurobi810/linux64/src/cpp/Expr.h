// Copyright (C) 2018, Gurobi Optimization, LLC
// All Rights Reserved
#ifndef _EXPR_CPP_H_
#define _EXPR_CPP_H_

class GRBExpr
{
  private:

  public:
    friend class GRBModel;
};
#endif
